function checkResult() {
  const roll = document.getElementById("roll").value.trim();
  const mother = document.getElementById("mother").value.trim().toLowerCase();
  const school = document.getElementById("school").value.trim();

  // Replace with your friend's correct info
  const correctRoll = "23604451";
  const correctMother = "anju";
  const correctSchool = "70125";

  if (
    roll === correctRoll &&
    mother === correctMother &&
    school === correctSchool
  ) {
    document.getElementById("resultContainer").innerHTML = `
      <h3>Your Result:</h3>
      <img src="images/result.jpg" alt="Result" />
    `;
  } else {
    document.getElementById("resultContainer").innerHTML =
      "<p style='color:red;'>Incorrect information. Please try again.</p>";
  }
}